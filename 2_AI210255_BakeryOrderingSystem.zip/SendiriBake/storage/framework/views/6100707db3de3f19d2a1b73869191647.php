<?php $__env->startSection('content'); ?>
<div class="edit-product-container">
    <h1>Edit Product</h1>
    <form class="edit-product-form" method="POST" action="<?php echo e(route('update.product', $product->Id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Display original product image if it exists -->
        <div>
            <?php if($product->Pimage): ?>
                <img id="originalImage" src="data:image/png;base64,<?php echo e(base64_encode($product->Pimage)); ?>" alt="Product Image" style= "width: 250px; height: 250px">
            <?php else: ?>
                <p>No original image available</p>
            <?php endif; ?>
        </div>

        <!-- Input field for uploading a new product image -->
        <div>
            <label for="productImage">New Product Image</label>
            <input type="file" id="productImage" name="productImage" accept="image/*" onchange="previewImage(event)">
            <!-- Image preview container -->
            <img id="imagePreview" src="#" alt="Product Image Preview" style="display: none; max-width: 200px;">
        </div>


        <!-- Other form fields for product details -->
        <div>
            <label for="productName">Product Name</label>
            <input type="text" id="productName" name="productName" value="<?php echo e($product->Pname); ?>">
        </div>

        <div>
            <label for="productPrice">Product Price</label>
            <input type="text" id="productPrice" name="productPrice" value="<?php echo e($product->price); ?>">
        </div>

        <div>
            <label for="productDescription">Product Description</label>
            <textarea id="productDescription" name="productDescription"><?php echo e($product->Pdesc); ?></textarea>
        </div>

        <div>
            <button type="submit">Update Product</button>
        </div>
    </form>

    <form class="delete-form" method="POST" action="<?php echo e(route('delete.product', $product->Id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete Product</button>
    </form>
</div>

<script>
    // Function to preview the selected image
    function previewImage(event) {
        // Display the new image preview and hide the original image
        document.getElementById('originalImage').style.display = 'none';
        document.getElementById('imagePreview').style.display = 'inline';

        // Set the preview image source
        document.getElementById('imagePreview').src = URL.createObjectURL(event.target.files[0]);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/admin/editProduct.blade.php ENDPATH**/ ?>