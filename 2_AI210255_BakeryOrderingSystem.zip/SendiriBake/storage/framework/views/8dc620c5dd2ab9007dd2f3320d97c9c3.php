<?php $__env->startSection('content'); ?>
<div style="display: flex; justify-content: space-between; align-items: center;">
    <h1 style="font-size: 35px; font-weight:bold;">Products List</h1>
    <a href="<?php echo e(route('add.product')); ?>"><button>Add New Product</button></a>
</div>
<div id="productImages">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="productItem" onclick="redirectToEdit(<?php echo e($product->Id); ?>)">
            <img src="data:image/png;base64,<?php echo e(base64_encode($product->Pimage)); ?>" alt="<?php echo e($product->Pname); ?>" onclick="redirectToEdit(<?php echo e($product->id); ?>)">
            <p><?php echo e($product->Pname); ?></p>
            <p>Price: RM <?php echo e($product->price); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    function redirectToEdit(productId) {
        window.location.href = `/edit-product/${productId}`;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/admin/manageCat.blade.php ENDPATH**/ ?>