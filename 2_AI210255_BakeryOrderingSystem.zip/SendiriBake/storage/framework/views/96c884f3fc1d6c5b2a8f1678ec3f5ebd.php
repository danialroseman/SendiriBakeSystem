<?php $__env->startSection('content'); ?>
    <section> 
        <h1 style="font-size: 35px; font-weight:bold;">Active Orders</h1>

        <?php if($orders->isNotEmpty()): ?>
            <table class="orders-table">
                <tr>
                <th>Order ID</th>
                    <th>Order Details</th>
                    <th>Total Price</th>
                    <th>Pickup Date</th>
                    <th>Status</th>
                    <th>Method</th>
                    <th>Receipt</th>
                    <th>Action</th>
                </tr>

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->Id); ?></td>
                        <td><?php echo e($order->orderdetails); ?></td>
                        <td><?php echo e($order->totalprice); ?></td>
                        <td><?php echo e($order->pickup); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td><?php echo e($order->payment_method); ?></td>
                        <td>
                            <?php if($order->receipt): ?>
                                <a href="<?php echo e(asset('storage/' . $order->receipt)); ?>" target="_blank">View Receipt</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('complete.order')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="orderId" value="<?php echo e($order->Id); ?>">
                                <button type="submit">Complete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php else: ?>
            <p>No active orders found.</p>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/admin/activeOrders.blade.php ENDPATH**/ ?>