;

<?php $__env->startSection('content'); ?>
        <h1 style="font-size: 35px; font-weight:bold;">Manage Order Quota</h1>
        <form class="editquota" method="POST" action="<?php echo e(route('quota.update')); ?>">
            <?php echo csrf_field(); ?>
            <div class="date-input">
                <label for="start">Start Date:</label>
                <input type="date" id="start" name="start">
                <label for="end">End Date:</label>
                <input type="date" id="end" name="end">
            </div>
            <label for="quota">Order Quota</label>
            <input type="text" id="quota" name="quota">
            <label for="basic">Basic Orders</label>
            <input type="text" id="basic" name="basic">
            <label for="custom">Custom Orders</label>
            <input type="text" id="custom" name="custom">
            <button type="submit">Save</button>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/admin/editQuota.blade.php ENDPATH**/ ?>