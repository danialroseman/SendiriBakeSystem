<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($pageTitle ?? 'Sendiri Bake'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <!-- Sidebar -->
    <section> 
        <div class="sidebar">
            <h1>Sendiri Bake</h1>
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <a href="<?php echo e(route('manage.catalogue')); ?>">Manage Catalogue</a>
            <a href="<?php echo e(route('manage.quota')); ?>">Manage Order Quota</a>
            <a href="<?php echo e(route('new.orders')); ?>">New Orders</a>
            <a href="<?php echo e(route('active.orders')); ?>">Active Orders</a>
            <a href="<?php echo e(route('reports')); ?>">Reports</a>
        </div>
    </section>

    

    <!-- Main content -->
    <section>
        <div class="main" style="padding-top: 50px;">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        
    </section>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</body>
</html>
<?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/admin/layout.blade.php ENDPATH**/ ?>