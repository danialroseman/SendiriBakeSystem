<?php $__env->startSection('content'); ?>
    <section> 
        <h1 style="font-size: 35px; font-weight:bold;">New Orders</h1>

        <?php if($orders->isNotEmpty()): ?>
            <table class="orders-table">
                <tr>
                    <th>Order ID</th>
                    <th>Order Details</th>
                    <th>Total Price</th>
                    <th>Pickup Date</th>
                    <th>Status</th>
                    <th>Method</th>
                    <th>Receipt</th>
                    <th>Action</th>
                </tr>

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->Id); ?></td> <!-- Ensure this matches your column name -->
                        <td>
                            <?php
                                $orderDetails = json_decode($order->orderdetails, true);
                            ?>
                            <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($name); ?>: x <?php echo e($item['quantity']); ?> (RM<?php echo e(number_format($item['price'], 2)); ?>)<br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                         </td>
                        <td>RM<?php echo e($order->totalprice); ?></td>
                        <td><?php echo e($order->pickup); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td><?php echo e($order->payment_method); ?></td>
                        <td>
                            <?php if($order->receipt): ?>
                                <a href="<?php echo e(Storage::url($order->receipt)); ?>" target="_blank">View Receipt</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('update.order.status')); ?>" class="update-status-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="orderId" value="<?php echo e($order->Id); ?>"> <!-- Ensure this matches your column name -->
                                <button type="button" class="accept-btn" data-status="accept">Accept</button>
                                <button type="button" class="reject-btn" data-status="rejected">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php else: ?>
            <p>No new orders found.</p>
        <?php endif; ?>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.accept-btn, .reject-btn').forEach(function (button) {
                button.addEventListener('click', function () {
                    let form = this.closest('form');
                    let statusInput = document.createElement('input');
                    statusInput.type = 'hidden';
                    statusInput.name = 'status';
                    statusInput.value = this.getAttribute('data-status');
                    form.appendChild(statusInput);
                    form.submit();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/admin/newOrders.blade.php ENDPATH**/ ?>