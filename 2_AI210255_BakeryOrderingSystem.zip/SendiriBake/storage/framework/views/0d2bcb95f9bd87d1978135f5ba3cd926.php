<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($pageTitle ?? 'Sendiri Bake'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custstyle.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body id="index-page">
    <div class="header">   
        <div class="logo">
            <img src="<?php echo e(asset('images/sendiribakelogo.png')); ?>" alt="Logo">
            <h1>Sendiri Bake</h1>
        </div>

        <div class="menu">
            <ul>
                <li><button onclick="window.location.href='<?php echo e(route('home')); ?>'">Home</button></li>
                <li><a href="#Orders">Orders</a></li>
            </ul>
        </div>

        <div class="cust-nav">
            <ul>
                <li><a href="#creampuffs">Creampuff and Eclairs</a></li>
                <li><a href="#cupcakes">Cupcakes</a></li>
                <li><a href="#munchies">Munchies</a></li>
                <li><a href="#cakes">Cakes</a></li>
            </ul>
        </div>
    </div>

    <div class="main-container">
        <div class="content-area">

            <div class="cart">
                <!-- Add Pickup Date Input -->
                <label for="pickupDate">Pickup Date:</label>
                <input type="date" id="pickupDate" name="pickupDate" required><br>

                <h2 style="padding-top:10px">Your Cart</h2>
                <div id="cart-items" class="cart-items">
                    <p id="empty-cart-message" class="empty-cart-message">Your cart is empty</p>
                </div>
                <hr>
                <p id="cart-subtotal">Subtotal: RM 0</p>
                <button id="checkout">Checkout</button>
            </div>

            <div class="product-display">
                <?php $__currentLoopData = ['creampuffs', 'cupcakes', 'munchies', 'cakes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section id="<?php echo e($category); ?>">
                        <h2><?php echo e(ucfirst($category)); ?></h2>
                        <div class="main" style="padding-top: 40px;">
                            <?php $__currentLoopData = $$category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-card" data-name="<?php echo e($product->Pname); ?>" data-desc="<?php echo e($product->Pdesc); ?>" data-price="<?php echo e($product->price); ?>" data-image="data:image/jpeg;base64,<?php echo e(base64_encode($product->Pimage)); ?>">
                                    <img src="data:image/jpeg;base64,<?php echo e(base64_encode($product->Pimage)); ?>" alt="<?php echo e($product->Pname); ?>">
                                    <h3><?php echo e($product->Pname); ?></h3>
                                    <!--<p><?php echo e($product->Pdesc); ?></p>-->
                                    <p>Price: RM<?php echo e($product->price); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

    <!-- Overlay Element -->
    <div id="overlay" class="overlay">
        <div class="overlay-content">
            <span class="close-btn">&times;</span>
            <img id="overlay-image" src="" alt="">
            <h3 id="overlay-name"></h3>
            <p id="overlay-desc"></p>
            <p id="overlay-price"></p>
            <button id="add-to-cart-overlay">Add to Cart</button>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scroll.js')); ?>"></script>
</body>
</html><?php /**PATH D:\XAMPP\htdocs\SendiriBake\SendiriBake\resources\views/customer/index.blade.php ENDPATH**/ ?>